lex example2.l
cc lex.yy.c -ll
./a.out

