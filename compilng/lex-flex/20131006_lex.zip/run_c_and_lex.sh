lex example2.l
gcc example2.c lex.yy.c -o example2.bin
./a.out

