//
// Solution for Exercise 7-3
//

#include "Contractor.h"

Contractor::Contractor(string s) : Worker(s) {}
