//
// Solution for Exercise 7-3
//

#include "Employee.h"

Employee::Employee(string s) : Worker(s) {}


