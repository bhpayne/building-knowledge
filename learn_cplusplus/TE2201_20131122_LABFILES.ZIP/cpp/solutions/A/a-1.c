//
//	Exercise 1-1
//
//	Write a C program which prints your name on the display with each 
//	name on a separate line.
//
#include <stdio.h>
main()
{
	printf("Your First name\n");
	printf("Your Last name\n");
}
