#include <stdio.h>

main()
{
	int a = 10, b = 20;
	double x = 10.5, y = 20.45;
	char name[10] = "michael";

	printf("%d %d\n", a, b);
	printf("%f %f\n", x, y);
	printf("%s\n", name);
	printf("%c\n", name[0]);
}



