struct Record {
	char name[50];
	double pay;
	int grade;
};
