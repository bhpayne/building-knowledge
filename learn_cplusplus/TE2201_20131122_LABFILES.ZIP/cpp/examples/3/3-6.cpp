//
//	3-6.cpp
//
#include <iostream>
int main( )		
{			
	int x, y;
	std::cout << "input a value ";
	std::cin >> x;
	std::cout << "You input  " << x << "\n";
	std::cout << "input two values ";
	std::cin >> x >> y;
	std::cout << x << " * " << y 
              << " is " << x * y << "\n";
	return 0;
}


