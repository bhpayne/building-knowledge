//
//	3-5.cpp
//
#include <iostream> 
int main( )		
{			
	int x = 10;
	std::cout << "x = " << x << "\n";
	std::cout << "x * x  = " << x * x << "\n";
	return 0;
}
